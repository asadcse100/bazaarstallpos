<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ProductCatalogue\\Providers\\ProductCatalogueServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ProductCatalogue\\Providers\\ProductCatalogueServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);